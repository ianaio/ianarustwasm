import * as wasm from "hello-wasm-pack";

wasm.greet();

